# MIS 120 Section 2 (36179)
# Donovan Martinez-Harrison
# Project 4: Academic_Performance_Tracker
# performance_tracker.py

import json
import csv
import os
import sqlite3
from datetime import datetime


DEFAULT_CONFIG = {
    "grade_weights": {
        "assignment": 0.40,
        "midterm": 0.25,
        "final": 0.35
    },
    "letter_grade_cutoffs": {
        "A": 90,
        "B": 80,
        "C": 70,
        "D": 60
    },
    "standing_thresholds": {
        "good_standing_min_grade": 70,
        "caution_min_grade": 60,
        "caution_requires_low_score": True,
        "low_score_threshold": 60
    },
    "school_name": "MIS University"
}


SAMPLE_STUDENTS = [
    # student_id, first_name, last_name, section, assignment, midterm, final
    ("S101", "Avery", "Brooks", 1, 92, 85, 90),
    ("S102", "Jordan", "Kim", 1, 78, 65, 72),
    ("S103", "Marcus", "Lee", 2, 55, 58, 62),
    ("S104", "Ariana", "Patel", 2, 88, 91, 86),
    ("S105", "Miguel", "Rivera", 3, 45, 52, 49),
    ("S106", "Emily", "Chen", 3, 96, 94, 98)
]

class DatabaseManager:
    """The DatabaseManager base class handles the generic SQLite mechanics: opening a connection, creating a
    cursor, executing parameterized queries, committing transactions, and closing the connection."""

    def __init__(self, db_path):
        """Store database path only. Do NOT connect yet."""
        self.db_path = db_path
        self._connection = None
        self._cursor = None

    def connect(self):
        """Open connection, create cursor, and initialize tables."""
        try:
            self._connection = sqlite3.connect(self.db_path)
            self._cursor = self._connection.cursor()
            self.create_tables()
        except sqlite3.Error as sqle:
            raise sqlite3.Error(f"Database connection failed: {sqle}")

    def create_tables(self):
        """Placeholder method — overridden by subclass."""
        pass

    def execute(self, sql, params=()):
        """Execute a parameterized SQL statement. Returns the cursor."""
        try:
            self._cursor.execute(sql, params)
            return self._cursor
        except sqlite3.Error as sqle:
            raise sqlite3.Error(f"SQL execution failed: {sqle}")

    def commit(self):
        """Commit transaction to disk."""
        if self._connection:
            self._connection.commit()

    def close(self):
        """Commit and close connection safely."""
        if self._connection:
            self._connection.commit()
            self._connection.close()
            self._connection = None
            self._cursor = None


class AcademicDatabase(DatabaseManager):
    """Subclass inherits from DatabaseManager and contains every SQL operation specific
    to the Academic Performance Tracker. It knows about students, sections, and scores. 
    It does not compute weighted grades, check academic standing, or validate score ranges."""

    def __init__(self, db_path):
        super().__init__(db_path)


    def create_tables(self):
        """Create students table, called automatically by connect()."""
        try:
            sql = """
            CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            section INTEGER NOT NULL,
            assignment_score REAL,
            midterm_score REAL,
            final_score REAL
            );
            """
            self.execute(sql)
            self.commit()

        except sqlite3.OperationalError:
            print("Error: Could not create table (OperationalError).")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue during table creation.")
        except sqlite3.Error:
            print("Error: Database error during table creation.")

    # -------------------------
    # REQUIRED METHODS
    # -------------------------

    def add_student(self, student):
        """Insert a new student row using Student object attributes."""
    
        try:
            sql = """
            INSERT INTO students (
                student_id, first_name, last_name, section,
                assignment_score, midterm_score, final_score
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """

            self.execute(sql, (
                student.student_id,
                student.first_name,
                student.last_name,
                student.section_number,
                student.assignment_score,
                student.midterm_score,
                student.final_score
            ))

            self.commit()
            return True

        except sqlite3.IntegrityError:
            raise sqlite3.IntegrityError("Student ID already exists.")
            return False
        except sqlite3.OperationalError as oe:
            print(f"Error: Could not add student (OperationalError): {oe}")
            return False
        except sqlite3.Error as sqle:
            print(f"Error: Database error while adding student (Error): {sqle}")
            return False


    def update_scores(self, student_id, assignment, midterm, final_score):
        """Update score columns only (no grade calculations)."""
        try:
            sql = """
            UPDATE students
            SET assignment_score = ?, midterm_score = ?, final_score = ?
            WHERE student_id = ?
            """

            self.execute(sql, (assignment, midterm, final_score, student_id))
            self.commit()

        except sqlite3.OperationalError:
            print("Error: Could not update scores.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue updating scores.")
        except sqlite3.Error:
            print("Error: Database error updating scores.")

    def update_section(self, student_id, new_section):
        """Update a student's section in the database after a transfer."""
        try:
            sql = """
            UPDATE students
            SET section = ?
            WHERE student_id = ?
            """
            self.execute(sql, (new_section, student_id))
            self.commit()

        except sqlite3.OperationalError:
            print("Error: Could not update student section.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue updating section.")
        except sqlite3.Error:
            print("Error: Database error updating section.")

        
    def delete_student(self, student_id):
        """Delete the row with matching student ID."""
        try:
            sql = "DELETE FROM students WHERE student_id = ?"
            self.execute(sql, (student_id,))
            self.commit()

        except sqlite3.OperationalError:
            print("Error: Could not delete student.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue deleting student.")
        except sqlite3.Error:
            print("Error: Database error deleting student.")


    # ---------------
    # QUERY METHODS
    # ---------------

    def get_all_students(self):
        """Return all students as list of tuples."""
        try:
            sql = """
            SELECT * FROM students
            """
            cursor = self.execute(sql)
            return cursor.fetchall()

        except sqlite3.OperationalError:
            print("Error: Could not retrieve students.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue retrieving students.")
        except sqlite3.Error:
            print("Error: Database error retrieving students.")
        return []

    def get_students_by_section(self, section_num):
        """Return students in a specific section as a list of tuples."""
        try:
            sql = """
            SELECT * FROM students 
            WHERE section = ?
            """
            cursor = self.execute(sql, (section_num,))
            return cursor.fetchall()

        except sqlite3.OperationalError:
            print("Error: Could not retrieve section students.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue retrieving section.")
        except sqlite3.Error:
            print("Error: Database error retrieving section.")
        return []

    def get_section_statistics(self, section_num, weights=None):
        """Uses SQL aggregates to compute:
        - enrollment (COUNT)
        - average (AVG)
        - highest (MAX)
        - lowest (MIN)
        Returns a dictionary."""

        if weights is None:
            weights = {"assignment": 0.40, "midterm": 0.25, "final": 0.35}
       
        try:
            sql = """
            SELECT 
                COUNT(*),
                AVG(
                    (assignment_score * ?) +
                    (midterm_score * ?) +
                    (final_score * ?)
                ),
                MAX(
                    (assignment_score * ?) +
                    (midterm_score * ?) +
                    (final_score * ?)
                ),
                MIN(
                    (assignment_score * ?) +
                    (midterm_score * ?) +
                    (final_score * ?)
                )
            FROM students
            WHERE section = ?
            AND assignment_score IS NOT NULL
            AND midterm_score IS NOT NULL
            AND final_score IS NOT NULL
            """

            cursor = self.execute(sql, (
                weights["assignment"], weights["midterm"], weights["final"],
                weights["assignment"], weights["midterm"], weights["final"],
                weights["assignment"], weights["midterm"], weights["final"],
                section_num
            ))
            result = cursor.fetchone()

            return {
                "enrollment": result[0],
                "average": result[1],
                "highest": result[2],
                "lowest": result[3]
            }

        except sqlite3.OperationalError as oe:
            print(f"Error: Could not compute statistics: {oe}")
        except sqlite3.IntegrityError as ie:
            print(f"Error: Integrity issue computing stats: {ie}")
        except sqlite3.Error as sqle:
            print(f"Error: Database error computing stats: {sqle}")

        return {
            "enrollment": 0,
            "average": None,
            "highest": None,
            "lowest": None
        }

    def student_exists(self, student_id):
        """Return True if student exists, False otherwise."""
        try:
            sql = """
            SELECT COUNT(*) 
            FROM students 
            WHERE student_id = ?
            """
            cursor = self.execute(sql, (student_id,))
            result = cursor.fetchone()

            return result[0] > 0

        except sqlite3.OperationalError:
            print("Error: Could not check student existence.")
        except sqlite3.IntegrityError:
            print("Error: Integrity issue checking student.")
        except sqlite3.Error:
            print("Error: Database error checking student.")

        return False
    
    def export_roster_backup(self, filename = "roster_backup.csv"):
        """Export all student records to CSV in Project 3 format."""

        try:
            rows = self.get_all_students()

            with open(filename, "w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)

                # REQUIRED: same column order as Project 3
                writer.writerow([
                    "student_id",
                    "first_name",
                    "last_name",
                    "section",
                    "assignment_score",
                    "midterm_score",
                    "final_score"
                ])

                writer.writerows(rows)
                return True, len(rows), None
        except Exception as e:
            return False, 0, str(e)
        

class Person:
    """Base class representing a person with a first and last name."""

    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name

    @property
    def first_name(self):
        return self._first_name

    @first_name.setter
    def first_name(self, value):
        value = str(value).strip()
        if not value:
            raise ValueError("First name cannot be empty.")
        self._first_name = value.title()

    @property
    def last_name(self):
        return self._last_name

    @last_name.setter
    def last_name(self, value):
        value = str(value).strip()
        if not value:
            raise ValueError("Last name cannot be empty.")
        self._last_name = value.title()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Student(Person):
    """Represents a student with an ID, section number, and grade scores."""

    def __init__(self, student_id, first_name, last_name, section_number, config):
        super().__init__(first_name, last_name)
        self.student_id = student_id
        self.section_number = section_number
        self._assignment_score = None
        self._midterm_score = None
        self._final_score = None
        self._config = config

    @property
    def student_id(self):
        return self._student_id

    @student_id.setter
    def student_id(self, value):
        value = str(value).strip().upper()
        if not value:
            raise ValueError("Student ID cannot be empty.")
        self._student_id = value

    @property
    def section_number(self):
        return self._section_number

    @section_number.setter
    def section_number(self, value):
        if value not in (1, 2, 3):
            raise ValueError("Section number must be 1, 2, or 3.")
        self._section_number = value

    @property
    def assignment_score(self):
        return self._assignment_score

    @assignment_score.setter
    def assignment_score(self, value):
        self._assignment_score = self._validate_score(value, "Assignment")

    @property
    def midterm_score(self):
        return self._midterm_score

    @midterm_score.setter
    def midterm_score(self, value):
        self._midterm_score = self._validate_score(value, "Midterm")

    @property
    def final_score(self):
        return self._final_score

    @final_score.setter
    def final_score(self, value):
        self._final_score = self._validate_score(value, "Final")

    def _validate_score(self, value, label):
        if value is None:
            return None
        if not isinstance(value, (int, float)):
            raise ValueError(f"{label} score must be numeric.")
        if value < 0 or value > 100:
            raise ValueError(f"{label} score must be between 0 and 100.")
        return float(value)

    def update_scores(self, assignment, midterm, final):
        self.assignment_score = assignment
        self.midterm_score = midterm
        self.final_score = final

    @property
    def weighted_grade(self):
        if None in (self.assignment_score, self.midterm_score, self.final_score):
            return None

        weights = self._config["grade_weights"]
        return (
            self.assignment_score * weights["assignment"] +
            self.midterm_score * weights["midterm"] +
            self.final_score * weights["final"]
        )

    @property
    def letter_grade(self):
        if self.weighted_grade is None:
            return "N/A"

        cutoffs = self._config["letter_grade_cutoffs"]
        if self.weighted_grade >= cutoffs["A"]:
            return "A"
        if self.weighted_grade >= cutoffs["B"]:
            return "B"
        if self.weighted_grade >= cutoffs["C"]:
            return "C"
        if self.weighted_grade >= cutoffs["D"]:
            return "D"
        return "F"

    @property
    def academic_standing(self):
        if None in (self.assignment_score, self.midterm_score, self.final_score):
            return "Incomplete"

        thresholds = self._config["standing_thresholds"]
        grade = self.weighted_grade
        low_threshold = thresholds["low_score_threshold"]

        if grade >= thresholds["good_standing_min_grade"]:
            return "Good Standing"

        if grade >= thresholds["caution_min_grade"]:
            if thresholds["caution_requires_low_score"]:
                if (
                    self.assignment_score < low_threshold or
                    self.midterm_score < low_threshold or
                    self.final_score < low_threshold
                ):
                    return "Academic Caution"
            else:
                return "Academic Caution"

        return "Academic Probation"

    @property
    def has_complete_scores(self):
        return None not in (self.assignment_score, self.midterm_score, self.final_score)

    def get_summary_row(self):
        grade_text = f"{self.weighted_grade:.2f}" if self.weighted_grade is not None else "N/A"
        assignment_text = f"{self.assignment_score:.2f}" if self.assignment_score is not None else "N/A"
        midterm_text = f"{self.midterm_score:.2f}" if self.midterm_score is not None else "N/A"
        final_text = f"{self.final_score:.2f}" if self.final_score is not None else "N/A"

        return (
            f"{self.student_id:<10}"
            f"{self.last_name + ', ' + self.first_name:<24}"
            f"{assignment_text:<12}"
            f"{midterm_text:<12}"
            f"{final_text:<12}"
            f"{grade_text:<12}"
            f"{self.letter_grade:<10}"
            f"{self.academic_standing}"
        )

    def get_full_record(self):
        assignment = f"{self.assignment_score:.2f}" if self.assignment_score is not None else "Not Entered"
        midterm = f"{self.midterm_score:.2f}" if self.midterm_score is not None else "Not Entered"
        final = f"{self.final_score:.2f}" if self.final_score is not None else "Not Entered"
        weighted = f"{self.weighted_grade:.2f}" if self.weighted_grade is not None else "N/A"

        return (
            "\nSTUDENT RECORD\n"
            "------------------------------\n"
            f"Student ID: {self.student_id}\n"
            f"Name: {self.first_name} {self.last_name}\n"
            f"Section: {self.section_number}\n"
            f"Assignment Score: {assignment}\n"
            f"Midterm Score: {midterm}\n"
            f"Final Score: {final}\n"
            f"Weighted Grade: {weighted}\n"
            f"Letter Grade: {self.letter_grade}\n"
            f"Academic Standing: {self.academic_standing}"
        )

    def get_removal_summary(self):
        grade_text = f"{self.weighted_grade:.2f}" if self.weighted_grade is not None else "N/A"
        return f"{self.first_name} {self.last_name} (ID: {self.student_id}) - Current Weighted Grade: {grade_text}"

    def to_record(self):
        return {
            "student_id": self.student_id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "section": self.section_number,
            "assignment_score": self.assignment_score,
            "midterm_score": self.midterm_score,
            "final_score": self.final_score
        }

    def __lt__(self, other):
        return (self.last_name, self.first_name, self.student_id) < (
            other.last_name,
            other.first_name,
            other.student_id
        )

    def __str__(self):
        return self.get_summary_row()


class Section:
    """Represents a course section containing multiple students and provides methods to manage them."""

    def __init__(self, section_number):
        self.section_number = section_number
        self._students = {}

    def add_student(self, student):
        if student.student_id in self._students:
            raise ValueError("Student ID already exists in this section.")
        self._students[student.student_id] = student

    def get_student(self, student_id):
        return self._students.get(student_id)

    def remove_student(self, student_id):
        return self._students.pop(student_id, None)

    def release_student(self, student_id):
        return self._students.pop(student_id, None)

    def accept_transferred_student(self, student):
        if student.student_id in self._students:
            raise ValueError("Student ID already exists in target section.")
        self._students[student.student_id] = student

    def clear(self):
        self._students.clear()

    def get_all_students_sorted(self):
        return sorted(self._students.values())

    @property
    def enrollment_count(self):
        return len(self._students)

    @property
    def complete_scores_count(self):
        return sum(1 for student in self._students.values() if student.has_complete_scores)

    @property
    def class_average(self):
        completed_grades = [
            student.weighted_grade
            for student in self._students.values()
            if student.weighted_grade is not None
        ]
        if not completed_grades:
            return None
        return sum(completed_grades) / len(completed_grades)

    @property
    def highest_grade(self):
        completed_grades = [
            student.weighted_grade
            for student in self._students.values()
            if student.weighted_grade is not None
        ]
        return max(completed_grades) if completed_grades else None

    @property
    def lowest_grade(self):
        completed_grades = [
            student.weighted_grade
            for student in self._students.values()
            if student.weighted_grade is not None
        ]
        return min(completed_grades) if completed_grades else None

    @property
    def standing_counts(self):
        counts = {
            "Good Standing": 0,
            "Academic Caution": 0,
            "Academic Probation": 0,
            "Incomplete": 0
        }
        for student in self._students.values():
            counts[student.academic_standing] += 1
        return counts

    def get_section_listing(self):
        lines = []
        lines.append(f"\nSECTION {self.section_number} STUDENTS")
        lines.append("-" * 110)

        if not self._students:
            lines.append("No students are currently enrolled in this section.")
            lines.append("Please add a student using Option 1 or choose another section.")
            return "\n".join(lines)

        lines.append(
            f"{'ID':<10}{'Name':<24}{'Assignment':<12}{'Midterm':<12}{'Final':<12}{'Grade':<12}{'Letter':<10}Standing"
        )

        for student in self.get_all_students_sorted():
            lines.append(student.get_summary_row())

        average_text = f"{self.class_average:.2f}" if self.class_average is not None else "N/A"
        lines.append("-" * 110)
        lines.append(f"Enrollment: {self.enrollment_count}")
        lines.append(f"Section Average: {average_text}")
        return "\n".join(lines)

    def get_stats(self):
        return {
            "enrollment": self.enrollment_count,
            "complete_scores": self.complete_scores_count,
            "average": self.class_average,
            "highest": self.highest_grade,
            "lowest": self.lowest_grade,
            "standing_counts": self.standing_counts
        }

    def get_report_text(self, school_name):
        date_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = []

        lines.append(school_name)
        lines.append(f"Section {self.section_number} Grade Report")
        lines.append(f"Date: {date_text}")
        lines.append("=" * 120)

        if not self._students:
            lines.append("This section has no enrolled students.")
            return "\n".join(lines)

        lines.append(
            f"{'ID':<10}{'Full Name':<24}{'Assignment':<12}{'Midterm':<12}{'Final':<12}{'Weighted':<12}{'Letter':<10}Standing"
        )
        lines.append("-" * 120)

        for student in self.get_all_students_sorted():
            full_name = f"{student.last_name}, {student.first_name}"
            assignment_text = f"{student.assignment_score:.2f}" if student.assignment_score is not None else "N/A"
            midterm_text = f"{student.midterm_score:.2f}" if student.midterm_score is not None else "N/A"
            final_text = f"{student.final_score:.2f}" if student.final_score is not None else "N/A"
            weighted_text = f"{student.weighted_grade:.2f}" if student.weighted_grade is not None else "N/A"

            lines.append(
                f"{student.student_id:<10}"
                f"{full_name:<24}"
                f"{assignment_text:<12}"
                f"{midterm_text:<12}"
                f"{final_text:<12}"
                f"{weighted_text:<12}"
                f"{student.letter_grade:<10}"
                f"{student.academic_standing}"
            )

        stats = self.get_stats()
        average_text = f"{stats['average']:.2f}" if stats["average"] is not None else "N/A"
        lines.append("=" * 120)
        lines.append(f"Section Enrollment: {stats['enrollment']}")
        lines.append(f"Section Average: {average_text}")
        lines.append(f"Good Standing: {stats['standing_counts']['Good Standing']}")
        lines.append(f"Academic Caution: {stats['standing_counts']['Academic Caution']}")
        lines.append(f"Academic Probation: {stats['standing_counts']['Academic Probation']}")
        lines.append(f"Incomplete: {stats['standing_counts']['Incomplete']}")

        return "\n".join(lines)

    def get_snapshot_data(self):
        stats = self.get_stats()
        return {
            "section": self.section_number,
            "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "enrollment": stats["enrollment"],
            "complete_scores": stats["complete_scores"],
            "section_average": round(stats["average"], 2) if stats["average"] is not None else None,
            "highest_grade": round(stats["highest"], 2) if stats["highest"] is not None else None,
            "lowest_grade": round(stats["lowest"], 2) if stats["lowest"] is not None else None,
            "standing_counts": stats["standing_counts"]
        }

    def __str__(self):
        return f"Section {self.section_number} - {self.enrollment_count} student(s)"


class Tracker:
    """Main class that manages the overall academic performance tracking system, including sections, students, and file operations."""

    def __init__(self):
        self.config = None

        self.sections = {
            1: Section(1),
            2: Section(2),
            3: Section(3)
        }

        self.__db = AcademicDatabase("tracker.db")

# ------------------
# PRIVATE HELPERS
# ------------------

    def _load_config(self, filename="config.json"):
        """Load configuration from JSON file or return default if not found."""
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as file:
                    config = json.load(file)
                    return config, "Configuration loaded successfully."
            except Exception as e:
                return DEFAULT_CONFIG.copy(), f"Could not load config file. Using default configuration: {e}"
        else:
            return DEFAULT_CONFIG.copy(), "Config file not found. Using default configuration."
    
    def _save_config(self, config, filename="config.json"):
        """Save configuration to JSON file."""
        try:
            with open(filename, "w", encoding="utf-8") as file:
                json.dump(config, file, indent=2)
                return True, f"Configuration saved successfully to {filename}."
        except Exception as e:
            return False, f"Could not save config file: {e}"

    def _write_text_file(self, filename, text):
        """Write plan text to a file. Used for .txt section reports."""
        try:
            with open(filename, "w", encoding="utf-8") as file:
                file.write(text)
                return True, f"Report saved to file '{filename}' successfully."
        except Exception as e:
            return False, f"Could not write report to file '{filename}': {e}"
   
    def _write_json_file(self, filename, data):
        """Write data to a JSON file. Used for section snapshot exports."""
        try:
            with open(filename, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=2)
                return True, f"Data saved to file '{filename}' successfully."
        except Exception as e:
            return False, f"Could not write data to file '{filename}': {e}"

    def _add_sample_students(self):
        """Add starter records so the program has useful demo data the first time it runs."""
        count = 0
        for student_id, first_name, last_name, section, assignment, midterm, final_score in SAMPLE_STUDENTS:
            if self.__db.student_exists(student_id):
                continue
            student = Student(student_id, first_name, last_name, section, self.config)
            student.update_scores(assignment, midterm, final_score)
            self.__db.add_student(student)
            self.sections[section].add_student(student)
            count += 1
        return count

    def startup(self):
        """Required startup sequence."""

        # load config (unchanged behavior)
        self.config, config_message = self._load_config()
        print(config_message)

        # connect to db (creates table automatically)
        self.__db.connect()

        # load all students from db
        records = self.__db.get_all_students()

        if not records:
            print("No existing records found. Loading sample students for demonstration.")
            count = self._add_sample_students()
            print(f"Loaded {count} sample student records into the database.")
            return

        # clear any existing in-memory data
        self.clear_all_sections()

        count = 0
        for row in records:
            student = Student(row[0], row[1], row[2], row[3], self.config)
            student.assignment_score = row[4]
            student.midterm_score = row[5]
            student.final_score = row[6]

            self.sections[row[3]].add_student(student)
            count += 1

        print(f"Loaded {count} student records from the database.")

    def shutdown(self):
        """Close database connection safely."""
        self.__db.close()

    def roster_file_exists(self, filename="roster.csv"):
        return os.path.exists(filename)

    def clear_all_sections(self):
        for section in self.sections.values():
            section.clear()

    def find_student_by_id(self, student_id):
        for section in self.sections.values():
            student = section.get_student(student_id)
            if student is not None:
                return student
        return None

    def find_student_with_section(self, student_id):
        for section in self.sections.values():
            student = section.get_student(student_id)
            if student is not None:
                return student, section
        return None, None

    def add_student(self, student_id, first_name, last_name, section_number):
        if section_number not in self.sections:
            raise ValueError("Invalid section number.")

        existing_student = self.find_student_by_id(student_id)
        if existing_student is not None:
            raise ValueError(
                f"Student ID {student_id} already exists in Section {existing_student.section_number}. "
                "Please use a different student ID instead of re-adding the same student."
            )

        new_student = Student(
            student_id,
            first_name,
            last_name,
            section_number,
            self.config
        )
        inserted = self.__db.add_student(new_student)
        if not inserted:
            raise ValueError("Failed to add student to the database.")
        
        self.sections[section_number].add_student(new_student)
        return new_student

    def remove_student(self, student_id):
        student, section = self.find_student_with_section(student_id)
        if student is None:
            return None
        self.__db.delete_student(student_id)
        return section.remove_student(student_id)

    def update_student_scores(self, student_id, assignment, midterm, final):
        student = self.find_student_by_id(student_id)
        if student is None:
            raise ValueError("Student not found.")
        student.update_scores(assignment, midterm, final)
        self.__db.update_scores(student_id, assignment, midterm, final)
        return student

    def search_by_initial_and_standing(self, initial, standing):
        initial = initial.strip().upper()
        standing = standing.strip().lower()

        matches = []
        for section in self.sections.values():
            for student in section.get_all_students_sorted():
                if (
                    student.last_name.upper().startswith(initial) and
                    student.academic_standing.lower() == standing
                ):
                    matches.append(student)
        return matches

    def transfer_student(self, student_id, new_section_number):
        if new_section_number not in self.sections:
            raise ValueError("Invalid target section.")

        student, current_section = self.find_student_with_section(student_id)
        if student is None:
            raise ValueError("Student not found.")
        if current_section.section_number == new_section_number:
            raise ValueError(f"Student {student_id} is already in Section {new_section_number}. Transfer cancelled.")

        moved_student = current_section.release_student(student_id)
        moved_student.section_number = new_section_number
        self.sections[new_section_number].accept_transferred_student(moved_student)
        self.__db.update_section(student_id, new_section_number)
        return moved_student
    
    def get_section_comparison_report(self):
        lines = []
        lines.append("\nSECTION COMPARISON REPORT")
        lines.append("=" * 50)

        for section_number in (1, 2, 3):
            stats = self.sections[section_number].get_stats()
            avg_text = f"{stats['average']:.2f}" if stats["average"] is not None else "N/A"
            high_text = f"{stats['highest']:.2f}" if stats["highest"] is not None else "N/A"
            low_text = f"{stats['lowest']:.2f}" if stats["lowest"] is not None else "N/A"

            lines.append(f"\nSection {section_number}")
            lines.append(f"Enrollment: {stats['enrollment']}")
            lines.append(f"Complete Scores: {stats['complete_scores']}")
            lines.append(f"Class Average: {avg_text}")
            lines.append(f"Highest Weighted Grade: {high_text}")
            lines.append(f"Lowest Weighted Grade: {low_text}")
            lines.append(f"Good Standing: {stats['standing_counts']['Good Standing']}")
            lines.append(f"Academic Caution: {stats['standing_counts']['Academic Caution']}")
            lines.append(f"Academic Probation: {stats['standing_counts']['Academic Probation']}")
            lines.append(f"Incomplete: {stats['standing_counts']['Incomplete']}")

        return "\n".join(lines)

    def get_all_records(self):
        """Compiles all student records from all sections into a list of dictionaries for saving to CSV."""

        records = []
        for section in self.sections.values():
            for student in section.get_all_students_sorted():
                records.append(student.to_record())
        return records

    def save(self):
        """Saves the current roster to the roster.csv file and returns a success status, message, and record count."""
        return True, "Roster saved successfully.", len(self.get_all_records())

    def load(self):
        """Load the roster from the database into the in-memory sections."""
        records = self.__db.get_all_students()
        self.clear_all_sections()

        for row in records:
            student = Student(row[0], row[1], row[2], row[3], self.config)
            student.assignment_score = row[4]
            student.midterm_score = row[5]
            student.final_score = row[6]
            self.sections[row[3]].add_student(student)

    def export_section_report(self, section_number):
        """Export a section's grade report to a text file."""

        if section_number not in self.sections:
            return False, "Invalid section number."

        section = self.sections[section_number]
        school_name = self.config["school_name"]
        report_text = section.get_report_text(school_name)
        filename = f"section_{section_number}_report.txt"
        return self._write_text_file(filename, report_text)

    def export_section_snapshot(self, section_number):
        """Export a section's snapshot data to a JSON file."""

        if section_number not in self.sections:
            return False, "Invalid section number."

        section = self.sections[section_number]
        db_stats = self.__db.get_section_statistics(section_number, self.config["grade_weights"])
        standing_counts = section.standing_counts

        snapshot_data = {
            "section": section_number,
            "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "enrollment": db_stats["enrollment"],
            "complete_scores": section.complete_scores_count,
            "section_average": round(db_stats["average"], 2) if db_stats["average"] is not None else None,
            "highest_grade": round(db_stats["highest"], 2) if db_stats["highest"] is not None else None,
            "lowest_grade": round(db_stats["lowest"], 2) if db_stats["lowest"] is not None else None,
            "standing_counts": standing_counts
        }

        filename = f"section_{section_number}_snapshot.json"
        return self._write_json_file(filename, snapshot_data)

    def update_grade_weights(self, assignment, midterm, final):
        """Update the grade weights in the configuration and save it to the config.json file."""

        total = assignment + midterm + final
        if round(total, 6) != 1.0:
            raise ValueError("The three weights must sum to 1.0.")

        self.config["grade_weights"]["assignment"] = assignment
        self.config["grade_weights"]["midterm"] = midterm
        self.config["grade_weights"]["final"] = final

        success, message = self._save_config(self.config)
        return success, message

    def __str__(self):
        return "Academic Performance Tracker"
    
    def export_backup(self):
        success, count, error = self.__db.export_roster_backup()

        if success:
            message = f"Backup successful: {count} record(s) written to roster_backup.csv"
        else:
            message = f"Backup failed. {error if error else ''}"
        return success, message


def display_menu():
    """Displays the main menu options to the user."""
    print("\nACADEMIC PERFORMANCE TRACKER")
    print("1. Add a Student to a Section")
    print("2. Remove a Student")
    print("3. Enter or Update a Student's Scores")
    print("4. Display One Student's Full Record")
    print("5. Display Students in a Section")
    print("6. Search by Last Name Initial and Standing")
    print("7. Section Comparison Report")
    print("8. Transfer a Student Between Sections")
    print("9. Quit")
    print("10. Export CSV Backup")
    print("11. Export Section Grade Report (.txt)")
    print("12. Export Section Snapshot to JSON")
    print("13. Update Configuration")


def prompt_section_number():
    """Keep asking until the user enters a valid section number."""
    while True:
        try:
            section = int(input("Enter section number (1, 2, or 3): ").strip())
            if section in (1, 2, 3):
                return section
            print("Invalid section. Please enter 1, 2, or 3.")
        except ValueError:
            print("Invalid input. Please enter a number: 1, 2, or 3.")


def prompt_score(label):
    """Keep asking until the user enters a valid score from 0 to 100."""
    while True:
        try:
            score = float(input(f"Enter {label} score (0-100): ").strip())
            if 0 <= score <= 100:
                return score
            print("Invalid score. Please enter a number from 0 to 100.")
        except ValueError:
            print("Invalid input. Please enter a numeric score from 0 to 100.")


def prompt_student_id(tracker):
    """Keep asking until the user enters a valid, unique student ID."""
    while True:
        student_id = input("Enter student ID, example S107: ").strip().upper()
        if not student_id:
            print("Student ID cannot be empty.")
            continue
        existing_student = tracker.find_student_by_id(student_id)
        if existing_student is not None:
            print(
                f"Student ID {student_id} already exists in Section {existing_student.section_number}. "
                "Please use a different student ID."
            )
            continue
        return student_id


def prompt_first_name():
    """Keep asking until the user enters a non-empty first name."""
    while True:
        first_name = input("Enter first name: ").strip()
        if not first_name:
            print("First name cannot be empty.")
            continue
        return first_name


def prompt_last_name():
    """Keep asking until the user enters a non-empty last name."""
    while True:
        last_name = input("Enter last name: ").strip()
        if not last_name:
            print("Last name cannot be empty.")
            continue
        return last_name


def prompt_existing_student_id(tracker, action):
    """Keep asking until the user enters an existing student ID."""
    while True:
        student_id = input(f"Enter student ID to {action}: ").strip().upper()
        if not student_id:
            print("Student ID cannot be empty.")
            continue
        student = tracker.find_student_by_id(student_id)
        if student is None:
            print("Student not found.")
            continue
        return student_id


def prompt_weight(label):
    """Keep asking until the user enters a valid weight between 0 and 1."""
    while True:
        try:
            weight = float(input(f"Enter new {label} weight (example 0.40): ").strip())
            if 0 <= weight <= 1:
                return weight
            print("Weight must be between 0 and 1.")
        except ValueError:
            print("Invalid input. Please enter a number between 0 and 1.")


def prompt_initial():
    """Keep asking until the user enters a single letter initial."""
    while True:
        initial = input("Enter last name initial: ").strip().upper()
        if len(initial) == 1 and initial.isalpha():
            return initial
        print("Invalid initial. Please enter a single letter.")


def prompt_standing():
    """Keep asking until the user enters a valid standing."""
    valid_standings = ["Good Standing", "Academic Caution", "Academic Probation", "Incomplete"]
    while True:
        standing = input("Enter standing (Good Standing, Academic Caution, Academic Probation, Incomplete): ").strip()
        if standing in valid_standings:
            return standing
        print("Invalid standing. Please enter one of: Good Standing, Academic Caution, Academic Probation, Incomplete.")


def main():
    tracker = Tracker()
    tracker.startup()

    while True:
        display_menu()
        choice = input("Enter your choice (1-13): ").strip()

        if choice == "1":
            student_id = prompt_student_id(tracker)
            first_name = prompt_first_name()
            last_name = prompt_last_name()
            section_number = prompt_section_number()

            try:
                student = tracker.add_student(student_id, first_name, last_name, section_number)
                tracker.save()
                print(f"Student {student.student_id} was added to Section {student.section_number} and saved to the database.")
            except ValueError as ve:
                print(f"Error: {ve}")

        elif choice == "2":
            student_id = prompt_existing_student_id(tracker, "remove")
            student = tracker.find_student_by_id(student_id)

            print(student.get_removal_summary())
            confirm = input("Are you sure you want to remove this student? (yes/no): ").strip().lower()
            if confirm == "yes":
                tracker.remove_student(student_id)
                tracker.save()
                print("Student removed successfully.")
            else:
                print("Removal cancelled.")

        elif choice == "3":
            student_id = prompt_existing_student_id(tracker, "update scores")
            assignment = prompt_score("assignment")
            midterm = prompt_score("midterm")
            final = prompt_score("final exam")

            try:
                student = tracker.update_student_scores(student_id, assignment, midterm, final)
                tracker.save()
                print(f"Scores updated successfully for {student.first_name} {student.last_name}. Academic Standing: {student.academic_standing}.")
            except ValueError as ve:
                print(f"Error: {ve}")

        elif choice == "4":
            student_id = prompt_existing_student_id(tracker, "view")
            student = tracker.find_student_by_id(student_id)

            print(student.get_full_record())

        elif choice == "5":
            section_number = prompt_section_number()
            print(tracker.sections[section_number].get_section_listing())

        elif choice == "6":
            initial = prompt_initial()
            standing = prompt_standing()

            matches = tracker.search_by_initial_and_standing(initial, standing)

            if not matches:
                print("No matching students found.")
            else:
                print("\nMATCHING STUDENTS")
                print("-" * 110)
                print(
                    f"{'ID':<10}{'Name':<24}{'Assignment':<12}{'Midterm':<12}{'Final':<12}{'Grade':<12}{'Letter':<10}Standing"
                )
                for student in matches:
                    print(student)

        elif choice == "7":
            print(tracker.get_section_comparison_report())

        elif choice == "8":
            student_id = prompt_existing_student_id(tracker, "transfer")
            new_section_number = prompt_section_number()

            try:
                student = tracker.transfer_student(student_id, new_section_number)
                tracker.save()
                print(f"Student {student.student_id} was transferred to Section {new_section_number} and saved to the database.")
            except ValueError as ve:
                print(f"Error: {ve}")

        elif choice == "9":
            tracker.shutdown()
            print("Goodbye. Session ended.")
            break

        elif choice == "10":
            success, message = tracker.export_backup()
            print(message)

        elif choice == "11":
            try:
                section_number = prompt_section_number()
                success, message = tracker.export_section_report(section_number)
                print(message)

            except ValueError:
                print("Invalid input. Section must be a number.")

        elif choice == "12":
            try:
                section_number = prompt_section_number()
                success, message = tracker.export_section_snapshot(section_number)
                print(message)

            except ValueError:
                print("Invalid input. Section must be a number.")

        elif choice == "13":
            print("\nCURRENT CONFIGURATION")
            print(json.dumps(tracker.config, indent=2))

            change_choice = input("Do you want to update the grade weights? (Y/N): ").strip().upper()
            if change_choice == "Y":
                assignment = prompt_weight("assignment")
                midterm = prompt_weight("midterm")
                final = prompt_weight("final")

                success, message = tracker.update_grade_weights(assignment, midterm, final)
                print(message)
                if success:
                    print("Grade weights updated for this session immediately.")
            else:
                print("Configuration update cancelled.")

        else:
            print("Invalid choice. Please enter a number from 1 to 13.")


if __name__ == "__main__":
    main()

