# Academic Performance Tracker (Database Edition)

A command-line Python program that manages student records for three course sections. It stores data in a SQLite database, calculates weighted grades and academic standing, and exports reports as text, CSV, and JSON files.

Built for **MIS 120 (Object-Oriented Programming)** at Sacramento State, Spring 2026.

## Features

- Add, remove, and transfer students between sections
- Enter and update assignment, midterm, and final exam scores
- Automatically calculate each student's weighted grade, letter grade, and academic standing
- Compare sections side by side (enrollment, average, highest and lowest grade)
- Search students by last-name initial and academic standing
- Export a section grade report (`.txt`), a section snapshot (`.json`), and a full roster backup (`.csv`)
- Change grade weights from the menu, saved to `config.json`
- Data is saved to the database automatically, with no manual saving needed

## Tools Used

- **Python 3** (standard library only, no installs needed)
- **SQLite** (`sqlite3`) for storing student records
- **SQL** parameterized queries and aggregate functions (`COUNT`, `AVG`, `MAX`, `MIN`) for section statistics
- **JSON** for configuration and snapshot exports
- **CSV** for roster backups

## How It Works

The program is organized into classes:

| Class | What it does |
| --- | --- |
| `DatabaseManager` | Handles the general SQLite connection: connecting, running queries, saving, closing |
| `AcademicDatabase` | Inherits from `DatabaseManager` and holds the SQL for students (add, update, delete, statistics) |
| `Person` / `Student` | A student's name, ID, section, and scores, with validation and grade calculations |
| `Section` | Manages the students in one section and builds that section's reports |
| `Tracker` | Ties everything together: loads settings, connects to the database, and runs each menu action |

Grades are weighted 40% assignments, 25% midterm, and 35% final by default. Weights, letter-grade cutoffs, and standing rules can be changed in `config.json`.

## How to Run

1. Install [Python 3](https://www.python.org/downloads/)
2. Download this repository
3. In a terminal, go to the project folder and run:

```
python performance_tracker.py
```

On the first run, the program creates `tracker.db` and loads six sample students so you can try every feature right away. If `config.json` is missing, it uses the default settings.

## Sample Output

Section 2 listing (menu option 5):

```
ID        Name                    Assignment  Midterm     Final       Grade       Letter    Standing
S103      Lee, Marcus             55.00       58.00       62.00       58.20       F         Academic Probation
S104      Patel, Ariana           88.00       91.00       86.00       88.05       B         Good Standing
Enrollment: 2
Section Average: 73.12
```

More examples are in the [`sample_output`](sample_output) folder: a section grade report and a JSON snapshot.

All sample students are fictional.

## What I Learned

- Designing classes with inheritance and encapsulation, including a base database class and a subclass for app-specific queries
- Using SQLite from Python, and writing parameterized SQL queries to keep data safe
- Using SQL aggregate functions to summarize data by section
- Validating user input and handling errors so the program doesn't crash
